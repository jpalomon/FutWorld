package es.urjc.code.dad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FutWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(FutWorldApplication.class, args);
	}
}
